rm(list=ls())
require(Rcpp)
set.seed(300)
#library(qbld)
#library(R.utils)
sourceCpp("SMCFunctions.cpp")
source("MH_functions.R")
#memory.limit(9999999999999)
########## Contact Matrix and Population ################################
#dem_data<-read.csv(file ='DemData.csv', header = TRUE)
#dem_data[288,1:95]
#Ashford_data<-as.numeric(gsub(",","",dem_data[288,5:95]))
Ashford_data<-c(1437, 1413, 1599, 1717, 1624, 1740, 1683, 1793, 1851, 1774, 1715, 1814, 1817, 1745, 1610, 1599, 1645,
                1549, 1487, 1133, 1014, 1129, 1210, 1447, 1315, 1439, 1412, 1466, 1569, 1511, 1490, 1577, 1539, 1610,
                1543, 1585, 1584, 1583, 1546, 1568, 1610, 1603, 1623, 1561, 1573, 1616, 1703, 1729, 1854, 1900, 1938,
                2027, 2025, 1930, 2052, 1944, 1944, 1840, 1791, 1724, 1606, 1526, 1435, 1417, 1392, 1383, 1285, 1293,
                 1359, 1293, 1370, 1438, 1560, 1691, 1248, 1232, 1171, 1121,  890,  768,  844,  754,  669,  624,  537,
                  535,  451,  370,  381,  335, 1171)
Pop_groups<-c()
Pop_groups[1]<-sum(Ashford_data[1:5])
Pop_groups[2]<-sum(Ashford_data[6:12])
Pop_groups[3]<-sum(Ashford_data[13:18])
Pop_groups[4]<-sum(Ashford_data[19:30])
Pop_groups[5]<-sum(Ashford_data[31:40])
Pop_groups[6]<-sum(Ashford_data[41:50])
Pop_groups[7]<-sum(Ashford_data[51:60])
Pop_groups[8]<-sum(Ashford_data[61:70])
Pop_groups[9]<-sum(Ashford_data[71:length(Ashford_data)])
sum(Pop_groups)

N_PM<-Pop_groups
orig.data<-read.csv(file ='contact_matrices.csv', header = TRUE)
M<-matrix(orig.data[244:324,4],9,9,byrow = FALSE)

PM_Groups<-list()
PM_Groups[[1]]<-c(1,2,3,4)
PM_Groups[[2]]<-c(5,6)
PM_Groups[[3]]<-c(7,8)
PM_Groups[[4]]<-c(9)
# find PM
PM<-matrix(0,4,4)
for(i in 1:length(PM_Groups)){
  vi=PM_Groups[[i]]
  for(j in 1:length(PM_Groups)){
    vj=PM_Groups[[j]]
    temps=0
    for(k in vi){
      temps=temps + ( N_PM[k]*sum(M[k,vj]) )
    }
    PM[i,j]=temps/sum(N_PM[vi])
  }
}
PM
round(PM,2)
age_groups<-seq(1,4,1)


Pop_vec=c(sum(Pop_groups[1:4]),sum(Pop_groups[5:6]),sum(Pop_groups[7:8]),sum(Pop_groups[9]))
sum(Pop_vec)
round(Pop_vec/sum(Pop_vec),4)

sum(round(Pop_vec/sum(Pop_vec),4))

################## Weekly Observed Data #########################################
orig.data1<-read.csv(file ='AshfordAge.csv', header = TRUE)

orig.data<-read.csv(file ='AshfordAge.csv', header = TRUE)
orig.data<-matrix(orig.data[,6],dim(orig.data)/22,22,byrow = TRUE)
dim(orig.data)
Bolton2G<-orig.data[,c(1,3,4,5,6,7,8,9,10,11,12,13,15,16,17:21)]
dim(Bolton2G)

Ysd_temp<-Bolton2G[8:147,]
dim(Ysd_temp)
colSums(Ysd_temp)
Ysd<-matrix(0,140,4)
Ysd<-cbind(rowSums(Ysd_temp[,1:6]),rowSums(Ysd_temp[,7:10]),rowSums(Ysd_temp[,11:14]),rowSums(Ysd_temp[,15:19]) )
dim(Ysd)

Yd_temp<-Bolton2G[126:8,]
dim(Yd_temp)
Yd<-matrix(0,119,4)
Yd<-cbind(rowSums(Yd_temp[,1:6]),rowSums(Yd_temp[,7:10]),rowSums(Yd_temp[,11:14]),rowSums(Yd_temp[,15:19]) )
dim(Yd)
# par(mar=c(2,2,2,2))
# plot(Yd[,1],type="o",col="red",ylim=c(min(Yd),max(Yd)),lwd=3)
# lines(Yd[,2],type="o",col="blue",lwd=3)
# lines(Yd[,3],type="o",col="pink",lwd=3)
# lines(Yd[,4],type="o",col="brown",lwd=3)

library(ggplot2)
df=data.frame(x=1:119,y=Yd[,1])
ggplot(df,aes(x = x, y = y))+theme_bw()+xlab("")+ylab("") +
  theme(text = element_text(size=30)) +
  geom_line(col='red') +
  geom_line(aes(x=(1:119),y=Yd[,2]),color='blue')+
  geom_line(aes(x=(1:119),y=Yd[,3]),color='green')+
  geom_line(aes(x=(1:119),y=Yd[,4]),color='brown')


Y<-matrix(0,17,4)
for(i in 1:(dim(Yd)[1]/7)){
  Y[i,]=colSums(Yd[( ((i-1)*7) + 1 ): (7*i), ])
}
Tend=dim(Y)[1]
Tend
sum(Y)
sum(Yd)
colSums(Y)
# plot(1:dim(Y)[1],Y[,1],main="Weekly Observed Data",type="o",ylim=c(min(Y),max(Y)),col="red",lwd=3)
# lines(1:dim(Y)[1],Y[,2],type="o",ylim=c(min(Y),max(Y)),col="blue",lwd=3)
# lines(1:dim(Y)[1],Y[,3],type="o",ylim=c(min(Y),max(Y)),col="green",lwd=3)
# lines(1:dim(Y)[1],Y[,4],type="o",ylim=c(min(Y),max(Y)),col="brown",lwd=3)
# colSums(Y)

num_intervals=17
library(ggplot2)
df=data.frame(x=1:17,y=Y[,1])
ggplot(df,aes(x = x, y = y))+theme_bw()+xlab("")+ylab("") +
  theme(text = element_text(size=30)) +
  geom_line(col='red') +
  geom_line(aes(x=(1:(num_intervals)),y=Y[,2]),color='blue')+
  geom_line(aes(x=(1:(num_intervals)),y=Y[,3]),color='green')+
  geom_line(aes(x=(1:(num_intervals)),y=Y[,4]),color='brown')


################## define the seeds of the process #######################
age_groups<-c(1,2,3,4)
count_s=0
i=0
seeds<-list()
num.seeds=0
dw<-c(147,140,133)
age_seeds<-list()
for(j in 1:length(dw)){
  count_s=count_s+1
  temps<-c()
  tempa<-c()
  for(k in dw[j]:(dw[j]-6)){
    for(ia in 1:length(age_groups)){
      temps<-c(temps,runif(2*Ysd[k-7,ia],min=i,max=i+1))
      tempa<-c(tempa,rep(ia,2*Ysd[k-7,ia]))
    }
    # temps<-c(temps,runif(sum(Ysd[k-7,]),min=i,max=i+1))
    #tempa<-c(tempa,sample(age_groups,sum(Ysd[k-7,]),replace = TRUE, prob=Pop_vec/sum(Pop_vec)))
    i=i+1
  }
  seeds[[count_s]]=temps
  age_seeds[[count_s]]=tempa
}
#seeds
hist_end=length(seeds)
hist_end

length(seeds[[1]])+length(seeds[[2]])+length(seeds[[3]])


XSa_seeds<-list()
XS1_list<-list()
XS2_list<-list()
XS3_list<-list()
XS4_list<-list()
for(j in 1:3){
  temp_list<-list()
  for(ia in 1:length(age_groups)){
    temp_list[[ia]]<-seeds[[j]][which(age_seeds[[j]]==ia)]
  }
  XS1_list[[j]]<-temp_list[[1]]
  XS2_list[[j]]<-temp_list[[2]]
  XS3_list[[j]]<-temp_list[[3]]
  XS4_list[[j]]<-temp_list[[4]]
}
XSa_seeds[[1]]<-XS1_list
XSa_seeds[[2]]<-XS2_list
XSa_seeds[[3]]<-XS3_list
XSa_seeds[[4]]<-XS4_list

#XSa_seeds
hist_end=length(seeds)
length(XSa_seeds)

############## Find roughly the number of Susceptibles on 11/9/2021#############################

Susc_vec1<-c((1-0.864+0.2)*sum(Ashford_data[1:25]), (1-0.825+0.2)*(sum(Ashford_data[26:30])),
             (1-0.825+0.2)*(sum(Ashford_data[31:35])),(1-0.718+0.2)*sum(Ashford_data[36:50]),
	     (1-0.808+0.2)*sum(Ashford_data[51:60]),
	     (1-0.889+0.2)*sum(Ashford_data[61:65]) ,
             (1-0.944+0.2)*sum(Ashford_data[66:70]) , (1-0.957+0.2)*sum(Ashford_data[71:75]) ,
             (1-0.958+0.2)*sum(Ashford_data[76:80]) ,
	     (1-0.950+0.2)*sum(Ashford_data[81:length(Ashford_data)]) )
# pan=0.5
# Susc_vec1<-c((1-(0.89*pan))*sum(Ashford_data[1:25]), (1-(0.854*pan))*(sum(Ashford_data[26:30])),
#              (1-(0.854*pan))*(sum(Ashford_data[31:35])),(1-(0.757*pan))*sum(Ashford_data[36:50]),
#              (1-(0.838*pan))*sum(Ashford_data[51:60]),
#              (1-(0.908*pan))*sum(Ashford_data[61:65]) ,
#              (1-(0.955*pan))*sum(Ashford_data[66:70]) , (1-(0.966*pan))*sum(Ashford_data[71:75]) ,
#              (1-(0.967*pan))*sum(Ashford_data[76:80]) ,
#              (1-(0.963*pan))*sum(Ashford_data[81:length(Ashford_data)]) )

# Susc_vec1<-c((1-(0.864/1))*sum(Ashford_data[1:25]), (1-(0.825/1))*(sum(Ashford_data[26:30])),
#              (1-(0.825/1))*(sum(Ashford_data[31:35])),(1-(0.718/1))*sum(Ashford_data[36:50]),
#              (1-(0.808/1))*sum(Ashford_data[51:60]),
#              (1-(0.889/1))*sum(Ashford_data[61:65]) ,
#              (1-(0.944/1))*sum(Ashford_data[66:70]) , (1-(0.957/1))*sum(Ashford_data[71:75]) ,
#              (1-(0.958/1))*sum(Ashford_data[76:80]) ,
#              (1-(0.950/1))*sum(Ashford_data[81:length(Ashford_data)]) )


Susc_vec<-c(sum(Susc_vec1[1:2]),sum(Susc_vec1[3:4]),sum(Susc_vec1[5:7]),sum(Susc_vec1[8:length(Susc_vec1)]))
Susc_vec
Susc_vec<-floor(Susc_vec)
Susc_vec
Pop_vec
sum(Pop_vec)
colSums(Y)
sum(Susc_vec)/sum(Pop_vec)
###########################################################################################################
num_particles=40000 # number of particles
Tend=17
num_intervals=Tend
# Latent Cases
bg=6.7/(1.8^2)
ag=6.7*bg 
ag/bg
sqrt(ag/(bg^2))

# Obesrved Cases
dg=8.8/(4.1^2)
cg=8.8*dg
cg/dg
sqrt(cg/(dg^2))


age_vec=seq(0,3,1)
age_vec
num_intervals=Tend
# plot(Y[,1],type="o",col="red",ylim=c(min(Y),max(Y)),lwd=3)
# lines(Y[,2],type="o",col="blue",lwd=3)
# lines(Y[,3],type="o",col="pink",lwd=3)
# lines(Y[,4],type="o",col="brown",lwd=3)
sum(rowSums(Y))
colSums(Y)
hist_end=length(seeds)
hist_end

age_vec=seq(0,3,1)

### Finding a,b
round(PM,2)

temp=0
for(i in 1:4){
  temp=temp + sum( (Susc_vec/Pop_vec)*PM[,i] )
}
a=2/temp
b=8/temp

#a=0
#b=1
min_d=1
max_d=10
min_v=0.0001
max_v=0.5
res<-list()
#List Initialization_FixedParameters(double min_d, double max_d,double min_v,double max_v,int num_particles){
res<-Initialization_FixedParameters(min_d,max_d,min_v,max_v,num_particles)
theta_d<-res[[1]]
theta_v<-res[[2]]

Ltheta_d<-log(theta_d)
Ltheta_v<-log(theta_v)
Particles<-list()
res<-list()
#List Initialization_step(double a, double b,double a_g,double b_g,int num_particles, int num_intervals,List seeds, List age_seeds, double hist_end, NumericMatrix PM,NumericVector age_vec,NumericVector Susc_vec,NumericVector Pop_vec){
res<-Initialization_step(a,b,ag,bg,num_particles,num_intervals,seeds,age_seeds,hist_end, PM,age_vec,Susc_vec,Pop_vec)
Particles[[1]]<-res
X_S<-res[[1]]
X_a<-res[[2]]
X_SAge<-res[[3]]
X_Sa<-res[[4]]
X_Susc<-res[[5]]
Susc_vec
#NumericVector weights_fun(NumericVector Y,List X_S,int IntervalInd,double beta, double a_g,double b_g,int num_particles,NumericMatrix X_a, List seeds,NumericVector theta_v,int Num_Agroups){
beta=0.5
ESS<-c()
ESSw<-c()
#margLikelihood<-c()
logl<-weights_fun(Y[1,],X_Sa,0,beta,cg,dg,num_particles,XSa_seeds,theta_v,length(age_groups))
logwt=logl
#logwv<-logw #+ AuxMult_fun(Y[2],X_S,1,beta,ag,bg,cg,dg,num_particles,X_a,v_nb,seeds,c,d)
maxwt=max(logwt)
temp=logwt-maxwt
wt=exp(temp)
w=wt/sum(wt)
logw<-log(w)
#margLikelihood<-c(margLikelihood,mean(exp(logl)))
ESSw<-c(ESSw,1/sum(w^2))
ESSw

D_m=0.99
h_m2=1 - ( ( ((3*D_m)-1)/(2*D_m)) ^2 )
h_m=sqrt(h_m2)
a_m2=1-h_m2
a_m=sqrt(a_m2)
a_m
h_m

indi<-seq(0,num_particles-1,1)
indv=indi+1
log_g<-rep(0,num_particles)
#Weights<-c()
X_d<-c()
X_v<-c()
X_dw<-c()
X_vw<-c()
X_dw<-rbind(X_dw,theta_d)
X_vw<-rbind(X_vw,theta_v)


#start.time<-Sys.time()
#Rprof("results.out")
for(IntervalInd in 1:(Tend-2)){
  
  print(IntervalInd)
  
  indi<-seq(0,num_particles-1,1)
  indv=indi+1
  
  m_res<-list()
  m_res=mu_fun(Ltheta_d,Ltheta_v,theta_d,theta_v,w,a_m)
  md=m_res[[1]]
  mv=m_res[[2]]
  Lmd=m_res[[3]]
  Lmv=m_res[[4]]
  
  #NumericVector AuxMult_fun(NumericVector Y,List X_S,List X_SAge,List X_Sa, int IntervalInd,double beta, double a_g,double b_g,double c_g, double d_g,int num_particles,NumericMatrix X_a, List seeds,List age_seeds,List XSa_seeds,NumericMatrix PM, NumericVector mv, NumericVector theta_d,NumericVector age_vec,List X_Susc,NumericVector Pop_vec ){
  log_aux<-AuxMult_fun(Y[IntervalInd+1,],X_S,X_SAge,X_Sa,IntervalInd,beta,ag,bg,cg,dg,num_particles,X_a,seeds,age_seeds,XSa_seeds,PM,mv,md,age_vec,X_Susc,Pop_vec)
  log_gt<-log_g+logw+log_aux
  maxgt=max(log_gt)
  temp=log_gt-maxgt
  gt=exp(temp)
  g=gt/sum(gt)
  log_g<-log(g)
  
  ESS<-c(ESS,1/sum(g^2)) 
  
  #List resampling(List X_S,List X_SAge,List X_Sa,List X_a, NumericVector W, int num_particles,NumericVector indi,List X_Susc){
  flagr=0
  if(ESS[IntervalInd]<=(num_particles)){
    res=resampling(X_S,X_SAge,X_Sa,X_a,g,num_particles,indi,X_Susc)
    X_S=res[[1]]
    X_a=res[[2]]
    X_SAge=res[[3]]
    X_Sa=res[[4]]
    X_Susc=res[[5]]
    indv=res[[6]]+1
    log_g<-rep(0,num_particles)
    flagr=1
  }
  
  #List RegeneratingPar_fun(NumericVector mv, NumericVector md,NumericVector theta_v,NumericVector theta_d, NumericVector indv, double h_m, NumericVector w){
  X_d<-rbind(X_d,theta_d)
  X_v<-rbind(X_v,theta_v)
  par_res=list()
  par_res=RegeneratingPar_fun(Lmv,Lmd,Ltheta_v,Ltheta_d,indv,h_m,w)
  Ltheta_d=par_res[[1]]
  Ltheta_v=par_res[[2]]
  
  theta_d=exp(Ltheta_d);
  theta_v=exp(Ltheta_v);
  
  print("propagation\n")
  #propagation<-function(X_a,X_S,X_SAge,X_Sa,PM,num_particles,IntervalInd,a_g,b_g,seeds,age_seeds,theta_d, age_vec,X_Susc,Pop_vec){
  res=propagation(X_a,X_S,X_SAge,X_Sa,PM,num_particles,IntervalInd+1,ag,bg,seeds,age_seeds,theta_d,age_vec,X_Susc,Pop_vec)
  
  X_S=res[[1]]
  X_a=res[[2]]
  X_SAge=res[[3]]
  X_Sa=res[[4]]
  X_Susc=res[[5]]
  #printf("weights, %f\n",max(X_a[IntervalInd,]))
  
  #NumericVector weights_fun(int Y,List X_S,int IntervalInd,double beta, double a_g,double b_g,int num_particles,NumericMatrix X_a,double v_nb)
  #Weights<-rbind(Weights,w)
  if(flagr==1){
    log_aux<-log_aux[indv]
  }
  #NumericVector weights_fun(NumericVector Y,List X_S,int IntervalInd,double beta, double a_g,double b_g,int num_particles,NumericMatrix X_a, List seeds,NumericVector theta_v,int Num_Agroups){
  logl<-weights_fun(Y[IntervalInd+1,],X_Sa,IntervalInd,beta,cg,dg,num_particles,XSa_seeds,theta_v,length(age_groups))
  #margLikelihood<-c(margLikelihood,mean(exp(logl)))
  logwt<-logl-log_aux
  maxwt=max(logwt)
  temp=logwt-maxwt
  wt=exp(temp)
  w=wt/sum(wt)
  logw<-log(w)
  ESSw<-c(ESSw,1/sum(w^2))
  ESSw
  print(ESSw[IntervalInd+1])
  # if(ESSw[(IntervalInd+1)]<(0.8*num_particles)){
  res=resampling(X_S,X_SAge,X_Sa,X_a,w,num_particles,indi,X_Susc)
  ind_sampl=res[[6]]+1
  X_dw<-rbind(X_dw,theta_d[ind_sampl])
  X_vw<-rbind(X_vw,theta_v[ind_sampl])
  Particles[[(IntervalInd+1)]]<-res
}
#Rprof(NULL)
#summaryRprof("results.out")
#end.time<-Sys.time()
#end.time-start.time
 
X_d<-rbind(X_d,theta_d)
X_v<-rbind(X_v,theta_v) 

par(mfrow=c(1,1))
plot(Y[,1],type="o",col="red",ylim=c(min(Y),max(Y)),lwd=3)
lines(Y[,2],type="o",col="blue",lwd=3)
lines(Y[,3],type="o",col="pink",lwd=3)
lines(Y[,4],type="o",col="brown",lwd=3)

sum(rowSums(Y))
colSums(Y)


res=Particles[[Tend-1]]
X_S=res[[1]]
X_a=res[[2]]
X_SAge=res[[3]]
X_Sa=res[[4]]
X_Susc=res[[5]]

thd=rep(mean(X_dw[Tend-1,]),num_particles)
thv=rep(mean(X_vw[Tend-1,]),num_particles)
for(IntervalInd in Tend:(Tend)){
  print(IntervalInd)
  res=propagation(X_a,X_S,X_SAge,X_Sa,PM,num_particles,IntervalInd,ag,bg,seeds,age_seeds,thd,age_vec,X_Susc,Pop_vec)
  X_S=res[[1]]
  X_a=res[[2]]
  X_SAge=res[[3]]
  X_Sa=res[[4]]
  X_Susc=res[[5]]
  Particles[[(IntervalInd)]]<-res
}
library(MASS)
Y_pred<-c()
for(IntervalInd in Tend:(Tend)){
  res=Particles[[IntervalInd]]
  X_S=res[[1]]
  X_a=res[[2]]
  X_SAge=res[[3]]
  X_Sa=res[[4]]
  X_Susc=res[[5]]  
  YPred<-list()
  tempP<-c()
  for(j in 1:num_particles){
    tempY<-c()
    XSa=X_Sa[[j]]
    for(ia in 1:length(age_groups)){
      Y.mean<-findMu_fun(IntervalInd-1,cg,dg,beta,XSa[[ia]],thv[j],XSa_seeds[[ia]])
      tempY<-c(tempY,rnegbin(1,mu=Y.mean,theta=1/thv[j]))
    }
    tempP<-cbind(tempP,tempY)
  }
}

Saved_Pred<-list(Y_pred=Y_pred)
save(Saved_Pred, file = "DataSc4_PredH.RData")
#################################################################################



alpha_est1<-matrix(0,num_intervals-1,num_particles)
alpha_est2<-matrix(0,num_intervals-1,num_particles)
alpha_est3<-matrix(0,num_intervals-1,num_particles)
alpha_est4<-matrix(0,num_intervals-1,num_particles)

for(i in 1:(num_intervals-1)){
  if((i+4)<=(Tend-1)){
    temp=Particles[[(i+4)]]
    X_S=temp[[1]]
    X_a=temp[[2]]
  }else{
    temp=Particles[[Tend-1]]
    X_S=temp[[1]]
    X_a=temp[[2]]
  }
  for(j in 1:num_particles){
    Xa=X_a[[j]]
    alpha_est1[i,j]=Xa[1,i]
    alpha_est2[i,j]=Xa[2,i]
    alpha_est3[i,j]=Xa[3,i]
    alpha_est4[i,j]=Xa[4,i]
  }
}


Saved_RdwH<-list(ESS=ESS,ESSw=ESSw,X_dw=X_dw,X_vw=X_vw,alpha_est1=alpha_est1,alpha_est2=alpha_est2,alpha_est3=alpha_est3,alpha_est4=alpha_est4,num_particles=num_particles)
save(Saved_RdwH, file = "DataSc4_RG4H.RData")
##################################################################
################ finding the reproduction numbers #################################
######################################################
EstY1<-matrix(0,num_intervals-1,num_particles)
EstY2<-matrix(0,num_intervals-1,num_particles)
EstY3<-matrix(0,num_intervals-1,num_particles)
EstY4<-matrix(0,num_intervals-1,num_particles)
for(i in 1:(num_intervals-1)){
  if((i+4)<=(Tend-1)){
    temp=Particles[[(i+4)]]
    X_Sa=temp[[4]]
  }else{
    temp=Particles[[Tend-1]]
    X_Sa=temp[[4]]
  }
  for(j in 1:num_particles){
    XSa=X_Sa[[j]]
    EstY1[i,j]=length(XSa[[1]][[i]])
    EstY2[i,j]=length(XSa[[2]][[i]])
    EstY3[i,j]=length(XSa[[3]][[i]])
    EstY4[i,j]=length(XSa[[4]][[i]])
  }
}



EstWeeklyHCases<-matrix(0,num_intervals-1,num_particles)
EstDailyHCases1<-matrix(0,112,num_particles)
EstDailyHCases2<-matrix(0,112,num_particles)
EstDailyHCases3<-matrix(0,112,num_particles)
EstDailyHCases4<-matrix(0,112,num_particles)

for(i in 1:(num_intervals-1)){
  if((i+4)<=(Tend-1)){
    temp=Particles[[(i+4)]]
    X_S=temp[[1]]
    X_Sa=temp[[4]]
  }else{
    temp=Particles[[Tend-1]]
    X_S=temp[[1]]
    X_Sa=temp[[4]]
  }
  for(j in 1:num_particles){
    EstWeeklyHCases[i,j]=length(X_S[[j]][[i]])
  }
  Wstar=((i-1)*7)+21
  Wend=(i*7)+21
  for(j in 1:num_particles){
    XSa=X_Sa[[j]]
    tempv1=XSa[[1]][[i]]
    tempv2=XSa[[2]][[i]]
    tempv3=XSa[[3]][[i]]
    tempv4=XSa[[4]][[i]]
    for(jj in Wstar:(Wend-1) ){
      cases_v=which(tempv1>=jj & tempv1<(jj+1))
      EstDailyHCases1[jj+1-21,j]=length(cases_v)
      cases_v=which(tempv2>=jj & tempv2<(jj+1))
      EstDailyHCases2[jj+1-21,j]=length(cases_v)
      cases_v=which(tempv3>=jj & tempv3<(jj+1))
      EstDailyHCases3[jj+1-21,j]=length(cases_v)
      cases_v=which(tempv4>=jj & tempv4<(jj+1))
      EstDailyHCases4[jj+1-21,j]=length(cases_v)
    }
  }
}

Saved_InfH<-list(EstY1=EstY1,EstY2=EstY2,EstY3=EstY3,EstY4,EstWeeklyHCases=EstWeeklyHCases,EstDailyHCases1=EstDailyHCases1,EstDailyHCases2=EstDailyHCases2,EstDailyHCases3=EstDailyHCases3,EstDailyHCases4=EstDailyHCases4)
save(Saved_InfH, file = "DataSc4_InfG4H.RData")

time.points<-seq(21,133,1)
time.points<-time.points[-1]
time.points<-time.points[-length(time.points)]
time.points<-c(time.points,132.99)
#lambda_est<-lambdaEst_fun(time.points,num_particles,seeds,Tend, a_g,b_g,X_S,X_a)
lambda_est1<-matrix(0,length(time.points),num_particles)
lambda_est2<-matrix(0,length(time.points),num_particles)
lambda_est3<-matrix(0,length(time.points),num_particles)
lambda_est4<-matrix(0,length(time.points),num_particles)
#lambda_est<-matrix(0,length(time.points),num_particles)
St1<-matrix(0,length(time.points),num_particles)
St2<-matrix(0,length(time.points),num_particles)
St3<-matrix(0,length(time.points),num_particles)
St4<-matrix(0,length(time.points),num_particles)
count_line=0
for(t in time.points){
  print(t)
  count_line=count_line+1
  indt<-find_interval(t,Tend-1,hist_end)
  if((indt+4+1)<=(Tend-1)){
    temp=Particles[[(indt+4+1)]]
    X_S=temp[[1]]
    X_SAge=temp[[3]]
    X_a=temp[[2]]
  }else{
    temp=Particles[[Tend-1]]
    X_S=temp[[1]]
    X_SAge=temp[[3]]
    X_a=temp[[2]]
  }
  for(j in 1:num_particles){
    #double lambda_fun(List T_N,List T_NAge,NumericVector alpha, double a_g,double b_g, double t, List seeds,List age_seeds,double Tend,NumericMatrix PM, int a_PM){
    res=lambda_fun(X_S[[j]],X_SAge[[j]],X_Sa[[j]][[1]],X_a[[j]],ag,bg,t,seeds,age_seeds,XSa_seeds,Tend-1,PM,0,Susc_vec,Pop_vec)
    lambda_est1[count_line,j]=res[[1]]
    St1[count_line,j]=res[[2]]

    res=lambda_fun(X_S[[j]],X_SAge[[j]],X_Sa[[j]][[2]],X_a[[j]],ag,bg,t,seeds,age_seeds,XSa_seeds,Tend-1,PM,1,Susc_vec,Pop_vec)
    lambda_est2[count_line,j]=res[[1]]
    St2[count_line,j]=res[[2]]
    
    res=lambda_fun(X_S[[j]],X_SAge[[j]],X_Sa[[j]][[3]],X_a[[j]],ag,bg,t,seeds,age_seeds,XSa_seeds,Tend-1,PM,2,Susc_vec,Pop_vec)
    lambda_est3[count_line,j]=res[[1]]
    St3[count_line,j]=res[[2]]
    
    res=lambda_fun(X_S[[j]],X_SAge[[j]],X_Sa[[j]][[4]],X_a[[j]],ag,bg,t,seeds,age_seeds,XSa_seeds,Tend-1,PM,3,Susc_vec,Pop_vec)
    lambda_est4[count_line,j]=res[[1]]
    St4[count_line,j]=res[[2]]    
  }
}
Saved_IntH<-list(lambda_est1=lambda_est1,lambda_est2=lambda_est2,lambda_est3=lambda_est3,lambda_est4=lambda_est4, St1=St1,St2=St2,St3=St3,St4=St4)
save(Saved_IntH, file = "DataSc4_IntG4H.RData")




####################################################################







################ finding the reproduction numbers #################################
R1<-matrix(0,length(time.points),num_particles)
R2<-matrix(0,length(time.points),num_particles)
R3<-matrix(0,length(time.points),num_particles)
R4<-matrix(0,length(time.points),num_particles)
count_line=0
for(t in time.points){
  print(t)
  count_line=count_line+1
  indt<-find_interval(t,Tend-1,hist_end)
  if((indt+4+1)<=(Tend-1)){
    temp=Particles[[(indt+4+1)]]
    X_S=temp[[1]]
    X_SAge=temp[[3]]
    X_a=temp[[2]]
  }else{
    temp=Particles[[Tend-1]]
    X_S=temp[[1]]
    X_SAge=temp[[3]]
    X_a=temp[[2]]
  }
  for(j in 1:num_particles){
    St_ag<-c( St1[count_line,j], St2[count_line,j], St3[count_line,j], St4[count_line,j])
    tempR<-c()
    for(i in 1:length(age_groups)){
      Xa=X_a[[j]]
      tempR<-c(tempR, sum( ( (St_ag/Pop_vec)*Xa[,indt+1])*PM[,i] ) )
    }
    R1[count_line,j]=tempR[1]
    R2[count_line,j]=tempR[2]
    R3[count_line,j]=tempR[3]
    R4[count_line,j]=tempR[4]
    
  }
}

Saved_RAgH<-list(R1=R1,R2=R2,R3=R3,R4=R4)
save(Saved_RAgH, file = "DataSc4_RAgH.RData")

#### finding Infectious at each point  ################################################

Inf1<-matrix(0,length(time.points),num_particles)
Inf2<-matrix(0,length(time.points),num_particles)
Inf3<-matrix(0,length(time.points),num_particles)
Inf4<-matrix(0,length(time.points),num_particles)
count_line=0
for(t in time.points){
  print(t)
  count_line=count_line+1
  indt<-find_interval(t,Tend-1,hist_end)
  if((indt+4+1)<=(Tend-1)){
    temp=Particles[[(indt+4+1)]]
    X_Sa=temp[[4]]
  }else{
    temp=Particles[[Tend-1]]
    X_Sa=temp[[4]]
  }
  for(j in 1:num_particles){
    tempInf<-find_Inf(t,indt,X_Sa[[j]],XSa_seeds,seeds,PM)
    
    Inf1[count_line,j]=tempInf[1]
    Inf2[count_line,j]=tempInf[2]
    Inf3[count_line,j]=tempInf[3]
    Inf4[count_line,j]=tempInf[4]
    
  }
}

Saved_InfAgH<-list(Inf1=Inf1,Inf2=Inf2,Inf3=Inf3,Inf4=Inf4)
save(Saved_InfAgH, file = "DataSc4_InfAgH.RData")


